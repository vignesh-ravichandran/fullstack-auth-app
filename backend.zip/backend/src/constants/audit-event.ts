export enum AUDIT_EVENT_NAMES {
    SIGN_UP = 'sign-up',
    SIGN_IN ='sign-in',
    REFRESH ='refresh'
  };