export const AUTH_ROUTES = {
  LOGIN: '/signin',
  SIGNUP: '/signup',
  USER: '/user',
  LOGOUT: '/logout',
  REFRESH: '/refresh-token',
};