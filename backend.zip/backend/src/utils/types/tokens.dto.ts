export class TokensDto {
  token: string;
  refreshToken: string;
}
