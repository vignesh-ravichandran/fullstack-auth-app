export const TOKEN_EXPIRY = {
  ACCESS: '15m' as const,
  REFRESH: '7d' as const,
};
