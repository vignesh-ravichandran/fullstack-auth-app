export const AUTH_ROUTES = {
  SIGN_IN: '/sign-in',
  SIGN_UP: '/sign-up',
  USER: '/user',
  SIGN_OUT: '/sign-out',
  REFRESH: '/refresh-token',
};
