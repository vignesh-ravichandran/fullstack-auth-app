export enum AUTH_FORM_TYPE {
  SIGN_IN = 'sign-in',
  SIGN_UP = 'sign-up',
}
