export const UI_MESSAGES = {
  SIGN_IN_SUCCESS: 'Welcome back!',
  SIGN_UP_SUCCESS: 'Account created!',
  SIGN_OUT_SUCCESS: 'You have been logged out.',
};
